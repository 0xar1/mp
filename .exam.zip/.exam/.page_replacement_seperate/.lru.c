#include<stdio.h>
#include<stdlib.h>
void lru(int n,int req[])
{
    struct lru
    {
        int data;
        struct lru* next;
    };
    struct lru* ptr;
    struct lru* previous;
    struct lru* header=(struct lru*)malloc(sizeof(struct lru));
    header->data=-1;
    header->next=NULL;
    printf("LRU");
    printf("\n");
    int frame[3],fn=0,i,j,flag=0,pageFaultCount=0;
    for(i=0;i<n;++i)
    {
        if(fn<3)
        {
            for(j=0;j<fn;++j)
            {
                if(frame[j]==req[i])
                    flag++;
            }
            if(flag==1)
            {
                printf("page %d is in frame\n",req[i]);
                flag--;
                ptr=header;
                previous=header;
                while(ptr->data != req[i])
                {
                    previous=ptr;
                    ptr=ptr->next;
                }
                previous->next=ptr->next;
                previous=ptr;
                ptr=header;
                while(ptr->next != NULL)
                {
                    ptr=ptr->next;
                }
                ptr->next=previous;
                previous->next=NULL;
            }
            else
            {
                printf("page %d is allocated  on frame %d\n",req[i],fn);
                frame[fn]=req[i];
                fn++;
                ptr=header;
                while(ptr->next != NULL)
                {
                    ptr=ptr->next;
                }
                struct lru* newlru=(struct lru*)malloc(sizeof(struct lru));
                ptr->next=newlru;
                newlru->data=req[i];
                newlru->next=NULL;
            }
        }
        else
        {
            for(j=0;j<3;++j)
            {
                if(frame[j]==req[i])
                    flag++;
            }
            if(flag==1)
            {
                printf("page %d is in frame\n",req[i]);
                flag--;
                ptr=header;
                while(ptr->data != req[i])
                {
                    previous=ptr;
                    ptr=ptr->next;
                }
                previous->next=ptr->next;
                previous=ptr;
                ptr=header;
                while(ptr->next != NULL)
                {
                    ptr=ptr->next;
                }
                ptr->next=previous;
                previous->next=NULL;
            }
            else
            {
                printf("page fault occured\n");
                pageFaultCount++;
                printf("page %d replaced with page %d\n",(header->next)->data,req[i]);
                for(j=0;j<3;++j)
                {
                    if(frame[j]==(header->next)->data)
                        break;
                }
                frame[j]=req[i];
                ptr=header->next;
                header->next=ptr->next;
                free(ptr);
                ptr=header;
                while(ptr->next != NULL)
                {
                    ptr=ptr->next;
                }
                struct lru* newlru=(struct lru*)malloc(sizeof(struct lru));
                ptr->next=newlru;
                newlru->data=req[i];
                newlru->next=NULL;
            }
        }
    }
    printf("Number of page faults is : %d\n",pageFaultCount);
}
void main()
{
    int i,n;
    printf("Number of frammes is : 3\n");
    printf("enter the number of page requests\n");
    scanf("%d",&n);
    int req[n];
    printf("enter the pages\n");
    for(i=0;i<n;++i)
        scanf("%d",&req[i]);
    printf("\n");
    lru(n,req);
}