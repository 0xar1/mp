#include<stdio.h>
#include<stdlib.h>
void fifo(int n,int req[])
{
    printf("FIFO");
    printf("\n");
	int frame[3],fn=0,k=0,i,j,flag=0,pageFaultCount=0;
    for(i=0;i<n;++i)
    {
        if(fn<3)
        {
            for(j=0;j<fn;++j)
            {
                if(frame[j]==req[i])
                    flag++;
            }
            if(flag==1)
            {
                printf("page %d is in frame\n",req[i]);
                flag--;
            }
            else
            {
                printf("page %d is allocated  on frame %d\n",req[i],fn);
                frame[fn]=req[i];
                fn++;
            }
        }
        else
        {
            for(j=0;j<3;++j)
            {
                if(frame[j]==req[i])
                    flag++;
            }
            if(flag==1)
            {
                printf("page %d is in frame\n",req[i]);
                flag--;
            }
            else
            {
                printf("page fault occured\n");
                pageFaultCount++;
                printf("page %d replaced with page %d\n",frame[k],req[i]);
                frame[k]=req[i];
                k=(k+1)%3;
            }
        }
    }
    printf("Number of page faults is : %d\n",pageFaultCount);
}
void main()
{
    int i,n;
    printf("Number of frammes is : 3\n");
    printf("enter the number of page requests\n");
    scanf("%d",&n);
    int req[n];
    printf("enter the pages\n");
    for(i=0;i<n;++i)
        scanf("%d",&req[i]);
    printf("\n");
    fifo(n,req);
}